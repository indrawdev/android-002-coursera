package com.paolone.dailyselfie;

/**
 * Created by pmorgano on 21/11/14.
 */
public class SelfiesGroup {
}

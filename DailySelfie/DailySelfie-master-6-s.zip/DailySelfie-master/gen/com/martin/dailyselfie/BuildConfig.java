/** Automatically generated file. DO NOT MODIFY */
package com.martin.dailyselfie;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}
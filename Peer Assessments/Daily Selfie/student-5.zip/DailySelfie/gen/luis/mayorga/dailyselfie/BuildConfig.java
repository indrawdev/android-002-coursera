/** Automatically generated file. DO NOT MODIFY */
package luis.mayorga.dailyselfie;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}
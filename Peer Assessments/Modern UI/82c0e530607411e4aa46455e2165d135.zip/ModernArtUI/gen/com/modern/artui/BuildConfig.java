/** Automatically generated file. DO NOT MODIFY */
package com.modern.artui;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}
package com.github.alexwibowo.coursera.moma;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.SeekBar;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;


public class RectangleArtActivity extends Activity {
    private static final String TAG = "RectangleArtActivity";

    public static final int SEEKBAR_MAX_RANGE = 50;
    public static final String SEEKBAR_PROGRESS_STATE = "SEEKBAR_PROGRESS";

    private SeekBar seekBar;
    private List<TextView> cells = new ArrayList<TextView>();
    private int[][] BASE_COLOURS;

    private DialogFragment moreInfoDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rectangle_art);
        setupBaseColors();
        setupUIComponents();

        if (savedInstanceState != null) {
            int seekBarProgress = savedInstanceState.getInt(SEEKBAR_PROGRESS_STATE);
            seekBar.setProgress(seekBarProgress);
            setCellColours(seekBarProgress);
        }else{
            setCellColours(0);
        }
        initEventHandling();
    }

    private void initEventHandling() {
        Log.d(TAG, "Setting up event handling");
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                setCellColours(progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });
    }

    private void setupUIComponents() {
        Log.d(TAG, "Setting up UI Components");
        cells.add((TextView) findViewById(R.id.leftColumnTop));
        cells.add((TextView) findViewById(R.id.leftColumnBottom));
        cells.add((TextView) findViewById(R.id.rightColumnTop));
        cells.add((TextView) findViewById(R.id.rightColumnMiddle));
        cells.add((TextView) findViewById(R.id.rightColumnBottom));

        seekBar = (SeekBar) findViewById(R.id.seekbar);
        seekBar.setMax(SEEKBAR_MAX_RANGE);
    }


    private void setCellColours(int colorOffset) {
        for (int i = 0; i < cells.size(); i++) {
            TextView cell = cells.get(i);

            // get drawable which has the border
            Drawable drawable = getResources().getDrawable(R.drawable.border);

            // create new color based on the base color and the seekbar progress
            int[] newColor = {BASE_COLOURS[i][0], BASE_COLOURS[i][1], BASE_COLOURS[i][2]};
            newColor[0] = newColor[0] + (colorOffset);
            newColor[1] = newColor[1] + (5 * colorOffset);
            newColor[2] = newColor[2] + (10 * colorOffset);

            // set background color of the drawable, then set it as background of the cell
            ((GradientDrawable) drawable).setColor(
                    Color.rgb(newColor[0], newColor[1], newColor[2])
            );
            cell.setBackground(drawable);
        }
    }

    private void setupBaseColors() {
        BASE_COLOURS = new int[][]{
                {200, 200, 200},
                {200, 0, 0},
                {0, 200, 0},
                {0, 0, 200},
                {200, 200, 0},
        };
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);

        // save the seekbar progress
        outState.putInt(SEEKBAR_PROGRESS_STATE, seekBar.getProgress());
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.rectangle_art, menu);
        return true;
    }

    private void visitMoma() {
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.moma.org"));
        startActivity(intent);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_moreinfo) {
            moreInfoDialog = AlertDialogFragment.newInstance();
            moreInfoDialog.show(getFragmentManager(), "Alert");
            return true;
        }
        return super.onOptionsItemSelected(item);
    }



    public static class AlertDialogFragment extends DialogFragment {
        public static AlertDialogFragment newInstance() {
            return new AlertDialogFragment();
        }

        @Override
        public Dialog onCreateDialog(Bundle savedInstanceState) {
            return new AlertDialog.Builder(getActivity())
                    .setMessage("Inspired by the works of artists such as Piet Mondrian and Ben Nicholson.\nClick below to learn more!")
                    .setCancelable(false)
                            // Set up No Button
                    .setNegativeButton("Not Now",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog,
                                                    int id) {
                                    ((RectangleArtActivity) getActivity())
                                            .moreInfoDialog.dismiss();
                                }
                            })
                            // Set up Yes Button
                    .setPositiveButton("Visit MOMA",
                            new DialogInterface.OnClickListener() {
                                public void onClick(
                                        final DialogInterface dialog, int id) {
                                    ((RectangleArtActivity) getActivity())
                                            .visitMoma();
                                }
                            }).create();
        }
    }
}
